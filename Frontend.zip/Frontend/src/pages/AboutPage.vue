<template>
    <div id="contact">
        <main>
            <article>
                <div id="header"><h2>Our Vision</h2></div>
                <p>In the bustling realm of the digital age, where every click leads to a new discovery and every scroll unveils endless possibilities, Civil-IT stands as a beacon of innovation and creativity. Specializing in the art of crafting bespoke websites, Civil-IT has carved out a niche for itself by seamlessly blending technology with artistic vision.</p>

                <p>Founded on the principles of passion and precision, Civil-IT began its journey with a singular mission: to transform ideas into captivating digital experiences. What started as a small team of enthusiasts has blossomed into a powerhouse of talent, where designers, developers, and strategists converge to create websites that not only meet but exceed expectations.</p>

                <p>At the heart of Civil-IT's ethos lies a commitment to understanding the unique essence of each client's brand. Every project commences with an in-depth discovery phase, where client aspirations are meticulously dissected and distilled into a creative blueprint. This initial groundwork ensures that every pixel and line of code serves a purpose—be it enhancing user experience, driving conversions, or amplifying brand presence.</p>

                <p>The process unfolds with a delicate dance between design and development. Civil-IT's designers, armed with a palette of colors and a canvas of possibilities, breathe life into wireframes and mockups, envisioning user interfaces that are not just aesthetically pleasing but also intuitively functional. Meanwhile, the development team meticulously translates these visions into reality, leveraging the latest technologies and frameworks to build robust, scalable websites that stand the test of time.</p>

                <p>But Civil-IT doesn't stop at mere functionality. They believe in the power of storytelling through design. Each website is imbued with a narrative that resonates with its target audience, evoking emotions and forging connections that go beyond the screen. Whether it's a sleek portfolio showcasing a photographer's finest works or an e-commerce platform seamlessly guiding shoppers through a curated collection, every website tells a compelling story of its own.</p>

                <p>Beyond the realms of design and development, Civil-IT prides itself on fostering long-term partnerships with its clients. From the initial consultation to post-launch support and beyond, they stand shoulder to shoulder with their clients, offering guidance, insights, and continuous optimization to ensure that their digital presence evolves in sync with their business goals.</p>

                <p>In an era where first impressions are often digital, Civil-IT understands the pivotal role that websites play as the face of modern businesses. They believe in pushing boundaries, embracing challenges, and delivering excellence with every click, scroll, and interaction. Their dedication to innovation and customer-centricity has earned them accolades and a loyal clientele who entrust them with their digital destinies.</p>

                <p>As Civil-IT continues to evolve in this ever-changing landscape, one thing remains constant: their unwavering commitment to crafting digital experiences that not only meet but exceed expectations. With each project, they redefine what it means to make a website—not merely as a collection of pages, but as a gateway to endless possibilities and unparalleled success in the digital realm.</p>

                <p style="text-align: center; text-indent: 0; font-weight: bold;">Civil-IT—where creativity meets technology, and dreams find their digital home.</p>
            </article>
        </main>
    </div>
</template>

<style scoped>

#contact {
    font-family: 'Arial', sans-serif;
    line-height: 1.6;
    margin: 0;
    padding: 0;
    color: #333;
}

header {
    background-color: #333;
    color: var(--color3);
    text-align: center;
    padding: 15px;
}

header h1 {
    margin: 0;
    font-size: 2rem; 
}

h2 {
    text-align: center;
    margin-bottom: 15px; 
}

main {
    color: var(--color1);
    max-width: 750px; 
    margin: 100px auto; 
    padding: 2% 4%; 
    background-color: var(--color3);
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); 
}

article {
    padding: 2%;
}

article h2 {
    font-size: 1.6rem;
    color: #333;
    border-bottom: 1px solid var(--color1); 
    padding-bottom: 8px; 
    margin-bottom: 15px;
}

article p {
    margin-bottom: 15px; 
    text-align: justify;
    line-height: 1.5; 
}

article p:last-child {
    text-align: center;
    text-indent: 0;
    font-weight: bold;
    margin-bottom: 0; 
}

</style>