<template>
<div id="contact">
  <div class="container">
  <div class="form-container">
    <div class="left-container">
      <div class="left-inner-container">
      <h2>Let's Chat</h2>
      <p>We're excited to help you build the website of your dreams. Please fill out the form and we'll get back to you as soon as possible.</p>
    </div>
      </div>
    <div class="right-container">
      <div class="right-inner-container">
      <form @submit.prevent="sendEmail" ref="form" autocomplete="on">
			<h2 class="lg-view">Contact Us</h2>
      <h2 class="sm-view">Let's Chat</h2>
           <p>* Required</p>
      <input type="text" placeholder="Name *"  name="name"required/>
      <input type="email" placeholder="Email *" name="email" required/>
			<input type="phone" placeholder="Phone" name="phone"/>
      <textarea rows="4" placeholder="Message"required name="message"></textarea>
			<input type="submit">Submit</input>
		  </form>
      </div>
    </div>
  </div>
</div>
</div>
</template>


<style scoped>
@import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

* {
  box-sizing:border-box;
  margin:0;
}

#contact {
  background: linear-gradient(90deg, var(--color2), var(--color1) 80%);
	display: flex;
	justify-content: center;
	align-items: center;
	flex-direction: column;
	font-family: 'Montserrat', sans-serif;
  font-size:10px;
	height: 120vh;
  overflow: hidden;
}

.container {
	background-color: var(--color3);
	border-radius: 5px;
  box-shadow: 0 14px 28px rgba(0,0,0,0.25), 
			0 10px 10px rgba(0,0,0,0.22);
	position: relative;
	overflow: hidden;
	width: 768px;
	max-width: 100%;
	min-height: 500px;
  min-width:370px;
}

h2 {
  font-size:2rem;
  margin-bottom:1rem;
}

.left-container h2{
  color: var(--color3);
}

.right-container h2 {
  color: var(--color2);
}

.form-container {
  display:flex;
}

.right-container {
  display:flex;
  flex:1;
  height:460px;
  background-color: var(--color3);
  justify-content:center;
  align-items:center;
}

.right-container p{
  color: var(--color1);
}

.left-container {
  display:flex;
  height:500px;
  background-color:var(--color2);
  flex:1;
  justify-content:center;
  align-items:center;
  color: var(--color3);
}

.left-container p {
  font-size:0.9rem;
  color: var(--color3);
}

.right-inner-container {
  width:70%;
  height:80%;
  text-align:center;
}

.left-inner-container {
  height:50%;
  width:80%;
  text-align:center;
  line-height:22px;
}

input:invalid {
  color: var(--color2);
}

input, textarea {
	background-color: #eee;
	border: none;
	padding: 12px 15px;
	margin: 8px 0;
	width: 100%;
  font-size:0.8rem;
}

input:focus, textarea:focus{
  outline:1px solid var(--color1);
}

input[type="submit"] {
	border-radius: 20px;
	border: 1px solid var(--color2);
	background-color: var(--color2);
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 12px 45px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
  cursor:pointer;
}

input[type="submit"]:hover {
  opacity:0.7;
}

@media only screen and (max-width: 600px) {
  .left-container{
    display: none;
  }
  .lg-view {
    display:none;  
  }
}

@media only screen and (min-width: 600px) {
  .sm-view {
    display:none;  
  }
}

form p {
  text-align:left;
}
</style>


<script>
import emailjs from 'emailjs-com';

export default {
  methods: {
    sendEmail() {
      emailjs.sendForm('service_ri2wmxb', 'main', this.$refs.form, 'VuMgYX_Apf8IEO4yI')
        .then(
          (response) => {
            console.log('SUCCESS!', response.status, response.text);
            alert('Submission sent successfully');
          },
          (error) => {
            console.log('FAILED...', error);
            alert('Error sending email');
          }
        );
    },
  },
};
</script>