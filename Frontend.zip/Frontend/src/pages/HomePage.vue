<template>
    <div id="home">
      <div id="container" class="banner">
        <div id="left">
          <h1>
            Power your
            <span v-for="(word, index) in words" :key="index" :style="{ color: colors[index] }" class="animated-span">
              {{ word }}
            </span>
          </h1>
          <router-link to="/about" id="read">Read about us</router-link>
        </div>
        
        <div id="right">
          <div class="slider" style="--quantity: 5">
            <div class="item" style="--position: 1"><img src="../assets/code_1.jpg" alt="Code"></div>
            <div class="item" style="--position: 2"><img src="../assets/code_2.png" alt="Code"></div>
            <div class="item" style="--position: 3"><img src="../assets/code_3.jpg" alt="Code"></div>
            <div class="item" style="--position: 4"><img src="../assets/code_4.jpg" alt="Code"></div>
            <div class="item" style="--position: 5"><img src="../assets/code_5.jpg" alt="Code"></div>
          </div>
        </div>
      </div>
  
      <div id="under">
        <div id="description">
          <h1>More than just a <span>website</span></h1>
          <p>
            Imagine a digital canvas where your dreams take shape, where ideas transcend into immersive experiences, and where your passion finds its home on the web. We craft more than mere websites; we breathe life into your vision, creating a digital presence that resonates with your audience and transforms possibilities into reality.
          </p>
          <br>
          <p>
            These are your ideas, your dreams—crafted pixel by pixel, code by code, into a digital masterpiece that speaks volumes about who you are and what you stand for. We don't just build websites; we sculpt narratives, weave emotions, and empower your online presence to leave an indelible mark on the digital landscape.
          </p>
        </div>
  
        <div id="features">
          <div class="block">
            <h2>Animation</h2>
            <p>
              At Civil-IT, we understand the transformative power of animation in digital experiences. Animation isn't just about adding movement; it's about storytelling through motion, engaging users, and creating memorable interactions. Whether it's subtle hover effects that captivate attention or dynamic transitions that guide users through content, every animation we design is crafted with purpose. From enhancing user experience to reinforcing brand identity, animation plays a crucial role in bringing websites to life. At the heart of our approach lies a blend of creativity and technical expertise, ensuring that every animation serves a strategic purpose in delivering impactful digital experiences.
            </p>
          </div>
  
          <div class="block">
            <h2>Accessibility</h2>
            <p>
              At Civil-IT, accessibility is not just a checkbox—it's a fundamental aspect of our design philosophy. We believe that every user, regardless of ability, deserves equal access to information and functionality on the web. That's why we adhere to accessibility standards and best practices, ensuring that our websites are inclusive and usable by everyone. From implementing semantic HTML for screen readers to providing keyboard navigation and ensuring color contrast for readability, we prioritize accessibility in every aspect of our design and development process. By embracing accessibility, we not only comply with legal requirements but also enrich user experiences, empowering individuals to interact with digital content seamlessly and independently.
            </p>
          </div>
  
          <div class="block">
            <h2>Professionalism</h2>
            <p>
              Professionalism is the cornerstone of Civil-IT's approach to every project we undertake. We pride ourselves on delivering high-quality, reliable, and transparent services to our clients. From the initial consultation to the final delivery, we prioritize clear communication, adherence to deadlines, and meticulous attention to detail. Our team of dedicated professionals brings expertise, creativity, and integrity to every aspect of web design and development. We value collaboration and strive to foster long-term relationships with our clients, offering proactive solutions and personalized support to meet their unique needs. At Civil-IT, professionalism isn't just a standard—it's a commitment to excellence that defines everything we do.
            </p>
          </div>
  
        </div>
  
        <div id="plans" class="block">
          <div class="plan-container">
            <h1>Starter</h1>
            <h2>Get your name out there</h2>
            <ul>
              <li>Website and Domain</li>
              <li>Basic Template</li>
              <li>Mobile-Friendly Design</li>
            </ul>
          </div>
  
          <div class="plan-container">
            <h1>Basic</h1>
            <h2>Begin your online presence</h2>
            <ul>
              <li>Website and Domain</li>
              <li>Basic animations</li>
              <li>SEO Optimization</li>
              <li>Contact Form</li>
            </ul>
          </div>
  
          <div class="plan-container">
            <h1>Intermediate</h1>
            <h2>Expand your capabilities</h2>
            <ul>
              <li>Website and Domain</li>
              <li>Database Access</li>
              <li>Website email</li>
              <li>Basic animations</li>
              <li>Blog Integration</li>
              <li>Analytics Dashboard</li>
            </ul>
          </div>
  
          <div class="plan-container">
            <h1>Advanced</h1>
            <h2>Professional-grade features</h2>
            <ul>
              <li>Website and Domain</li>
              <li>Database Access</li>
              <li>Website Email</li>
              <li>Advanced animations</li>
              <li>Admin console</li>
              <li>Advanced SEO Tools</li>
              <li>E-commerce Integration</li>
            </ul>
          </div>
  
          <div class="plan-container">
            <h1>Professional</h1>
            <h2>All-inclusive package</h2>
            <ul>
              <li>Website and Domain</li>
              <li>Database Access</li>
              <li>Website Email</li>
              <li>Admin console</li>
              <li>One on one contact with a developer</li>
              <li>Monthly updates for free</li>
              <li>Priority Support</li>
              <li>Custom Design Services</li>
              <li>Marketing Consultation</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        words: ['Future', 'Dreams', 'Business', 'Portfolio'],
        colors: ['#00FFFF', '#f0f0f0', '#f0f0f0', '#f0f0f0'], 
      };
    },
  };
  </script>
  
  <style scoped>
  @import url('https://fonts.cdnfonts.com/css/ica-rubrik-black');
  @import url('https://fonts.cdnfonts.com/css/poppins');
  
  @keyframes appear {
    from {
      opacity: 0;
      clip-path: inset(100% 100% 0 0);
      transform: translateY(-100%);
    }
    to {
      opacity: 1;
      clip-path: inset(0 0 0 0);
      transform: translateY(0);
    }
  }
  
  .block {
    animation: appear ease 1s;
    animation-timeline: view();
    animation-range: entry 0% cover 40%;
  }
  
  #container {
    padding: 5%;
    background: linear-gradient(360deg, var(--color1), var(--color2) 100%);
    box-shadow: 0 6px 10px rgb(65, 51, 65), 0pc 0 0 1px rgba(0, 0, 0, 0.1);
    height: 50vh;
  }
  
  #left {
    padding-top: 20%;
    float: left;
    width: 40%;
  }
  
  #left span {
    display: inline-block;
  }
  
  #right {
    width: 50%;
    float: right;
    position: relative;
  }
  
  .slider {
    position: absolute;
    width: 200px;
    height: 200px;
    margin-top: 150px;
    left: 40%;
    transform-style: preserve-3d;
    transform: perspective(1000px);
    animation: autoRun 20s linear infinite;
    z-index: 2;
  }
  
  @keyframes autoRun {
    from {
      transform: perspective(1000px) rotateX(-16deg) rotateY(0deg);
    }
    to {
      transform: perspective(1000px) rotateX(-16deg) rotateY(360deg);
    }
  }
  
  .slider .item {
    position: absolute;
    inset: 0;
    transform-origin: center;
    transform: rotateY(calc((var(--position) - 1) * (360deg / var(--quantity)))) translateZ(200px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.5);
  }
  
  .slider .item img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 10px;
  }
  
  #container h1 {
    font-size: 2.5rem;
    color: var(--color3);
  }
  
  h1 {
    color: var(--color1);
  }
  
  .animated-span {
    display: inline-block;
    opacity: 0;
    animation: rollAnimation 12s infinite;
  }
  
  @keyframes rollAnimation {
    0% { opacity: 0; }
    10% { opacity: 1; }
    20% { opacity: 0; }
    100% { opacity: 0; }
  }
  
  .animated-span:nth-child(1) { animation-delay: 0s; }
  .animated-span:nth-child(2) { animation-delay: 3s; }
  .animated-span:nth-child(3) { animation-delay: 6s; }
  .animated-span:nth-child(4) { animation-delay: 9s; }
  
  #under {
    color: var(--color1);
  }
  
  #under p {
    text-indent: 5%;
  }
  
  #features {
    background-color: var(--color4);
    color: white;
    box-shadow: 12px 12px 12px rgba(255, 162, 1, 0.1), -10px -10px 10px white;
  }
  
  #features div {
    margin-bottom: 5%;
    padding: 1% 10%;
  }
  
  #description {
    padding: 5% 20% 10% 20%;
  }
  
  #read {
    position: relative;
    width: max-content;
    display: inline-block;
    padding: 10px 20px;
    text-decoration: none;
    color: var(--color3);
    background-color: var(--color2);
    border-radius: 20px;
    transition: background-color 0.3s ease;
    margin-left: 5%;
    z-index: 0;
  }
  
  #read:hover {
    background-color: var(--color4);
  }
  
  #plans {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    gap: 20px;
    margin-bottom: 2%;
  }
  
  .plan-container h2 {
    position: relative;
    color: transparent;
    background: linear-gradient(to right, var(--color4), var(--color2));
    -webkit-background-clip: text;
    background-clip: text;
  }
  
  .plan-container {
    flex: 1 1 calc(20% - 20px);
    background-color: #f0f0f0;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 12px 12px 12px rgba(0, 0, 0, 0.1), -10px -10px 10px white;
    text-align: center;
  }
  
  .plan-container h1, .plan-container h2 {
    text-align: center;
  }
  
  .plan-container ul {
    padding-left: 0;
    list-style-type: none;
  }
  
  @media screen and (max-width: 1023px) {
    #left {
      width: 100%;
    }
  
    #right {
      display: none;
    }
  
    .slider {
      width: 160px;
      height: 200px;
      left: calc(50% - 80px);
    }
  
    .slider .item {
      transform: rotateY(calc((var(--position) - 1) * (360deg / var(--quantity)))) translateZ(200px);
    }
  
    #container {
      height: 60vh;
    }
  
    #description {
      padding: 10% 15%;
    }
  }
  
  @media screen and (max-width: 1023px) and (orientation: landscape) {
    #container {
      height: 120vh;
    }
    #left {
      padding-top: 0%;
    }
    #right {
      display: none;
    }
  }
  
  </style>
  