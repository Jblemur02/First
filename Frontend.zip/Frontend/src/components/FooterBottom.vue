<template>
    <div id="footer">
        <p>&copy; 2024 Civil-IT LLC. All rights reserved.</p>
    </div>
</template>

<style scoped>
#footer {
    background-color: var(--color1); 
    padding: 2rem; 
    text-align: center; 
    color: #fff; 
    font-family: 'Montserrat', sans-serif; 
    font-size: 0.9rem; 
    border-top: 1px solid #444; 
    box-shadow: 0 -4px 10px rgba(0, 0, 0, 0.1);
}

#footer p {
    margin: 0; 
    line-height: 1.5; 
}

@media (max-width: 768px) {
    #footer {
        padding: 1rem;
        font-size: 0.8rem; 
    }
}
</style>
