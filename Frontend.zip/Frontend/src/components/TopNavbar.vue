<template>
    <nav>
      <router-link to="/">Home</router-link>
      <router-link to="/about">About</router-link>
      <router-link to="/contact">Contact</router-link>
    </nav>
  </template>
  
  <style scoped>

nav {
  width: 100%;
  background-color: var(--color1);
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1), 0 6px 20px rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: center;
  padding: 1rem;
  position: fixed; /* Optional: Keeps navbar fixed at the top */
  top: 0;
  left: 0;
  z-index: 1000; /* Ensures the navbar is above other content */
}

nav a {
  color: var(--color3);
  padding: 0.5rem 1rem;
  margin: 0 1rem;
  text-decoration: none;
  transition: background-color 0.3s ease, color 0.3s ease;
  border-radius: 4px;
}

nav a.router-link-exact-active {
  background-color: var(--color2);
  color: var(--color1);
}

nav a:hover {
  background-color: var(--color4);
  color: var(--color1);
}

@media (max-width: 1023px) {
  nav {
    flex-direction: row; /* Ensure horizontal layout on mobile */
    justify-content: space-around; /* Spread items evenly */
    padding: 0.5rem;
  }

  nav a {
    margin: 0;
    padding: 0.5rem 1rem;
  }

  nav a:hover {
    background-color: var(--color4);
    color: var(--color1);
  }
}

  </style>
  