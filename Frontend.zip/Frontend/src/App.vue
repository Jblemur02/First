<script setup>
import Navbar from './components/TopNavbar.vue';
import Footer from './components/FooterBottom.vue';
</script>

<template>
  <div>
    <Navbar />
    <RouterView 
      class="router-view" 
      v-slot="{Component}"
    >
      <Transition name="page-slide" mode="out-in">
        <component :is="Component" />
      </Transition>
    </RouterView>
    <Footer />
  </div>
</template>